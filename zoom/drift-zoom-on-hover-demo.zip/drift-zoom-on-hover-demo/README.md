# Drift: Zoom on Hover Demo

A Pen created on CodePen.io. Original URL: [https://codepen.io/imgix/pen/WrRmLb](https://codepen.io/imgix/pen/WrRmLb).

This is a demo of Drift, a simple, lightweight, no-dependencies JavaScript "zoom on hover" tool from imgix. Move your mouse over the image (or touch it) to see it in action. This demo uses the simple included theme, but it's very easy to extend and customize to fit your needs. 